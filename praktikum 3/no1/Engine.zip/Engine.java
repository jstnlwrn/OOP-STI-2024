public interface Engine {
    public void startEngine();
    public void stopEngine();
}
